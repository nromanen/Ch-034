var express = require("express"),
    router = express.Router(),
    bodyParser = require("body-parser"),
    mongoose = require("mongoose");

router.post("/", function(req, res) {});

router.get("/:id", function(req, res) {});

module.exports = router