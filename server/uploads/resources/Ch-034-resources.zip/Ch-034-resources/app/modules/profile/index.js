define(function(require) {
  "use strict";

  return {
    Model: require("./model/profileModel"),
    View: require("./view/profileView")
  };
});