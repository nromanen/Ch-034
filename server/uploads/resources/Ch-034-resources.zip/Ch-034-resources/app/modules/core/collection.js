define(function(require) {
    "use strict";

    var Backbone = require("backbone"),

    Collection = Backbone.Collection.extend({

    });
    return Collection;
});