define(function(require) {
    "use strict";

    return {
        View: require("./views/SidebarView")
    };
});