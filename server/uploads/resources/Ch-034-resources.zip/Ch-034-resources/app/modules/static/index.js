define(function(require){
    return {
        View: require("./views/StaticPagesView")
    };
});