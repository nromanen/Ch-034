define(function(require) {
  "use strict";

  return {
    Model: require("./model/registerModel"),
    View: require("./view/registerView")
  };
});