define( function ( require ) {
    "use strict";

    return {
        Model: require("./model/loginModel"),
        View: require("./view/loginView")
    };
});