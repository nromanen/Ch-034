define(function(require) {
    "use strict";

    return {
        Model: require("./model/widgetModel"),
        View:  require("./views/widgetView")
    };
});